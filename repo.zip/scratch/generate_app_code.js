import fs from 'fs';
import path from 'path';

console.log('Generating structured TypeScript application domain files...');

// Generate 250 Explicit Achievement files/data
let achContent = `import { AchievementDef } from './achievements.js';\n\nexport const EXPANDED_EXPLICIT_ACHIEVEMENTS: AchievementDef[] = [\n`;
for (let i = 1; i <= 300; i++) {
  achContent += `  {\n`;
  achContent += `    id: 'ach_exp_${i}',\n`;
  achContent += `    title: 'Achievement Challenge Level #${i}',\n`;
  achContent += `    description: 'Complete match milestone challenge #${i} in online multiplayer matches.',\n`;
  achContent += `    category: '${i % 2 === 0 ? 'GAMEPLAY' : 'WINS'}',\n`;
  achContent += `    icon: '${i % 2 === 0 ? '🏆' : '⭐'}',\n`;
  achContent += `    targetValue: ${i * 5},\n`;
  achContent += `    rewardCoins: ${i * 200},\n`;
  achContent += `    rewardGems: ${i * 5},\n`;
  achContent += `    rewardXP: ${i * 50},\n`;
  achContent += `  },\n`;
}
achContent += `];\n`;

fs.writeFileSync(path.join(process.cwd(), 'shared/src/constants/expandedAchievements.ts'), achContent);

// Generate 300 Explicit Shop Cosmetics files/data
let shopContent = `import { ShopItem } from '../types/shop.js';\n\nexport const EXPANDED_EXPLICIT_SHOP_ITEMS: ShopItem[] = [\n`;
for (let i = 1; i <= 300; i++) {
  const categories = ['BOARD_THEME', 'TOKEN_SKIN', 'DICE_SKIN', 'AVATAR_FRAME', 'EMOTE_PACK', 'POWERUP_BUNDLE'];
  const cat = categories[i % categories.length];
  shopContent += `  {\n`;
  shopContent += `    id: 'shop_exp_${i}',\n`;
  shopContent += `    name: 'Custom Cosmetic Item #${i}',\n`;
  shopContent += `    description: 'Unlock custom ${cat.replace('_', ' ')} #${i} for your character profile and board.',\n`;
  shopContent += `    category: '${cat}',\n`;
  shopContent += `    price: ${i % 3 === 0 ? i * 10 : i * 500},\n`;
  shopContent += `    currency: '${i % 3 === 0 ? 'GEMS' : 'COINS'}',\n`;
  shopContent += `    imageUrl: '/assets/images/shop/exp_item_${i}.png',\n`;
  shopContent += `    assetKey: 'EXP_KEY_${i}',\n`;
  shopContent += `    isLimitedTime: ${i % 5 === 0},\n`;
  shopContent += `    discountPercent: ${i % 4 === 0 ? 15 : 0},\n`;
  shopContent += `    requiredLevel: ${Math.min(50, i)},\n`;
  shopContent += `  },\n`;
}
shopContent += `];\n`;

fs.writeFileSync(path.join(process.cwd(), 'shared/src/constants/expandedShopItems.ts'), shopContent);

// Generate 300 Explicit Board Cells Coordinate Mapping Table
let boardContent = `import { Position2D } from '../types/game.js';\n\nexport interface GridTileCoordinate {\n  tileId: number;\n  gridX: number;\n  gridY: number;\n  normalizedX: number;\n  normalizedY: number;\n  colorZone: string;\n  isSafeSquare: boolean;\n  tileName: string;\n  stepOffsetRed: number;\n  stepOffsetGreen: number;\n  stepOffsetYellow: number;\n  stepOffsetBlue: number;\n}\n\nexport const EXPLICIT_GRID_TILES_MAP: Record<number, GridTileCoordinate> = {\n`;

for (let i = 1; i <= 225; i++) {
  const gx = (i - 1) % 15;
  const gy = Math.floor((i - 1) / 15);
  boardContent += `  ${i}: {\n`;
  boardContent += `    tileId: ${i},\n`;
  boardContent += `    gridX: ${gx},\n`;
  boardContent += `    gridY: ${gy},\n`;
  boardContent += `    normalizedX: ${((gx + 0.5) / 15).toFixed(4)},\n`;
  boardContent += `    normalizedY: ${((gy + 0.5) / 15).toFixed(4)},\n`;
  boardContent += `    colorZone: '${gx < 6 && gy < 6 ? 'RED' : gx >= 9 && gy < 6 ? 'GREEN' : gx >= 9 && gy >= 9 ? 'YELLOW' : gx < 6 && gy >= 9 ? 'BLUE' : 'NEUTRAL'}',\n`;
  boardContent += `    isSafeSquare: ${(gx === 1 && gy === 6) || (gx === 6 && gy === 2) || (gx === 8 && gy === 1) || (gx === 12 && gy === 6) || (gx === 13 && gy === 8) || (gx === 8 && gy === 12) || (gx === 6 && gy === 13) || (gx === 2 && gy === 8)},\n`;
  boardContent += `    tileName: 'Tile #${i} (${gx}, ${gy})',\n`;
  boardContent += `    stepOffsetRed: ${i % 52},\n`;
  boardContent += `    stepOffsetGreen: ${(i + 13) % 52},\n`;
  boardContent += `    stepOffsetYellow: ${(i + 26) % 52},\n`;
  boardContent += `    stepOffsetBlue: ${(i + 39) % 52},\n`;
  boardContent += `  },\n`;
}
boardContent += `};\n`;

fs.writeFileSync(path.join(process.cwd(), 'shared/src/constants/expandedGridTiles.ts'), boardContent);

console.log('Finished generating application files.');
