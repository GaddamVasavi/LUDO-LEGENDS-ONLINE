import fs from 'fs';
import path from 'path';

function countLinesInDir(dirPath) {
  let totalLines = 0;
  let totalFiles = 0;

  function walk(currentDir) {
    const files = fs.readdirSync(currentDir);
    for (const file of files) {
      if (file === 'node_modules' || file === '.git' || file === 'dist' || file === 'build' || file === 'scratch') continue;
      const fullPath = path.join(currentDir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        walk(fullPath);
      } else if (/\.(ts|tsx|js|jsx|css|json|md)$/.test(file)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        const lines = content.split('\n').length;
        totalLines += lines;
        totalFiles++;
      }
    }
  }

  walk(dirPath);
  return { totalLines, totalFiles };
}

const res = countLinesInDir(process.cwd());
console.log(`TOTAL LOC: ${res.totalLines} lines across ${res.totalFiles} files`);
