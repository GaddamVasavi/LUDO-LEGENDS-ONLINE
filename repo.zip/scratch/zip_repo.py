import os
import zipfile

print("Creating repo.zip via Python zipfile module...")
zip_filename = "repo.zip"

if os.path.exists(zip_filename):
    os.remove(zip_filename)

ignored_dirs = {'node_modules', 'dist', 'build', '.idea', '.vscode'}
ignored_files = {'repo.zip', 'LUDO-LEGENDS-ONLINE.zip'}

with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        # Filter out ignored directories
        dirs[:] = [d for d in dirs if d not in ignored_dirs]
        for file in files:
            if file in ignored_files:
                continue
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, '.')
            zipf.write(file_path, arcname)

print("✅ Successfully generated repo.zip containing all files and .git directory!")
