import http from 'http';

const postData = JSON.stringify({
  username: 'vasavi',
  email: 'vasavigaddam@gmail.com',
  password: 'password123',
});

const req = http.request(
  {
    hostname: 'localhost',
    port: 5000,
    path: '/api/v1/auth/register',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData),
    },
  },
  (res) => {
    let body = '';
    res.on('data', (chunk) => (body += chunk));
    res.on('end', () => {
      console.log('STATUS:', res.statusCode);
      console.log('RESPONSE:', body);
    });
  }
);

req.on('error', (e) => {
  console.error('REQUEST ERROR:', e.message);
});

req.write(postData);
req.end();
