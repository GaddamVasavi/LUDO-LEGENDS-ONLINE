import fs from 'fs';
import path from 'path';

function countSourceLines(dirPath) {
  let totalLines = 0;
  let totalFiles = 0;
  const extensionCounts = {};

  function walk(currentDir) {
    const files = fs.readdirSync(currentDir);
    for (const file of files) {
      if (file === 'node_modules' || file === '.git' || file === 'dist' || file === 'build' || file === 'scratch') continue;
      const fullPath = path.join(currentDir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        walk(fullPath);
      } else {
        const ext = path.extname(file).toLowerCase();
        if (['.ts', '.tsx', '.js', '.jsx', '.css'].includes(ext)) {
          const content = fs.readFileSync(fullPath, 'utf8');
          const lines = content.split('\n').length;
          totalLines += lines;
          totalFiles++;
          extensionCounts[ext] = (extensionCounts[ext] || 0) + lines;
        }
      }
    }
  }

  walk(dirPath);
  return { totalLines, totalFiles, extensionCounts };
}

const res = countSourceLines(process.cwd());
console.log(`PURE SOURCE CODE LOC (ts, tsx, js, jsx, css only): ${res.totalLines} lines across ${res.totalFiles} files`);
console.log('Breakdown:', res.extensionCounts);
