import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

console.log('Creating repo.zip including .git folder...');

const zipPath = path.join(process.cwd(), 'repo.zip');
if (fs.existsSync(zipPath)) {
  fs.unlinkSync(zipPath);
}

// Use PowerShell Compress-Archive or git archive / zip command
try {
  // PowerShell Compress-Archive command ensuring .git is included while excluding node_modules
  const cmd = `powershell -Command "Get-ChildItem -Path '.' -Force -Exclude 'node_modules', 'repo.zip' | Compress-Archive -DestinationPath 'repo.zip' -Force"`;
  execSync(cmd, { stdio: 'inherit' });
  console.log('✅ repo.zip successfully created including .git directory!');
} catch (err) {
  console.error('Error creating zip:', err.message);
}
